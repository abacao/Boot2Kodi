#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright 2014
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,HTMLParser,sys
from tools import *
from xbmcgui import ListItem
from BeautifulSoup import BeautifulSoup

versao = '0.0.3'
addon_id = 'plugin.video.anitube'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/img/'
fanart = addonfolder + '/fanart.jpg'
site_base = 'http://anitube.se/'


def Menu_Principal():
	addDir('',site_base + 'categories',1,artfolder + 'categorias5.png')
	addDir('',site_base + 'videos/basic/mr',2,artfolder + 'recentes.png')
	addDir('',site_base,4,artfolder + 'pesquisa.png')
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin('Container.SetViewMode(500)')

def Listar_categorias(url):
	print url
	html = abrir_url(url)
	html = unicode(html, 'ascii', errors='ignore')
	soup = BeautifulSoup(html)

	a = []
	categorias = soup.findAll("li", { "class" : "mainList" })
	#resultados = content.findAll("td",  { "width" : "1%" })
	for categoria in categorias:
		temp = [categoria.a["href"],"%s" % (categoria.a.img["alt"].encode('ascii', 'ignore')),categoria.a.img["src"],categoria.a["title"]] 
		a.append(temp)
	total = len(a)
	
	for url2, titulo, img, plot in a:
		titulo = cleanHtml(titulo)
		addDir(titulo,url2,2,img,True,total,plot)
	pages = soup.find('ul',{ "id" : "pagination-flickr" }).findAll('a')
	print pages
	for prox_pagina in pages:
		if prox_pagina.text == 'Next':
			addDir('Página Seguinte >>',prox_pagina['href'],1,artfolder + 'proxpagina.png')
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin('Container.SetViewMode(503)')

def Listar_episodios(url):
	print url
	html = abrir_url(url)
	html = unicode(html, 'ascii', errors='ignore')
	soup = BeautifulSoup(html)

	a = []
	categorias = soup.findAll("li", { "class" : "mainList" })
	#resultados = content.findAll("td",  { "width" : "1%" })
	for categoria in categorias:
		try:
			temp = [categoria.a["href"],"%s" % (categoria.a.img["alt"].encode('ascii', 'ignore')),categoria.a.img['src'],''] 
			a.append(temp)
		except:
			pass
	a.sort()
	total = len(a)
	
	for url2, titulo, img, plot in a:
		titulo = cleanHtml(titulo)
		addDir(titulo,url2,3,img,True,total,plot)
	try:
		pages = soup.find('ul',{ "id" : "pagination-flickr" }).findAll('a')
		for prox_pagina in pages:
			if prox_pagina.text == 'Next':
				addDir('Página Seguinte >>',prox_pagina['href'],2,artfolder + 'proxpagina.png')
	except:
		pass
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin('Container.SetViewMode(502)')

def Resolve_episodio(url):
	print url
	html = abrir_url(url)
	print html
	xml_url = "http://anitube.se/nuevo/econfig.php?key=" + re.findall(r'src="http://www.anitube.se/player/config.php\?key=(.+?)"',html)[0]
	xml = abrir_url(xml_url)
	soup = BeautifulSoup(xml)
	file_url = ''
	filehd_url = ''
	image = ''
	try:
		file_url = soup.config.file.text
	except:
		pass
	try:
		filehd_url = soup.config.filehd.text
	except:
		pass
	try:
		image = soup.config.image.text
	except:
		pass
	if filehd_url:
		addLink('Hd', filehd_url, image)
	if file_url:
		addLink('Sd', file_url, image)

def Pesquisa():
	keyb = xbmc.Keyboard('', 'Pesquisar...')
	keyb.doModal()
	if (keyb.isConfirmed()):
		search = keyb.getText()
		parametro_pesquisa=urllib.quote(search)
		url = 'http://anitube.xpg.uol.com.br/search/?search_id=' + str(parametro_pesquisa)
		Listar_episodios(url)

		###################################################################################



################################################
#    Funções relacionadas a media.             #
#                                              #
################################################

def addLink(name,url,iconimage):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	return ok

def addDir(name,url,mode,iconimage,pasta=True,total=1,plot=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	liz.setInfo( type="video", infoLabels={ "title": name, "plot": plot } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
	return ok




################################################
#    Pega os parametros                        #
#                                              #
################################################

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

      
params=get_params()
url=None
name=None
mode=None
iconimage=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

try:        
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Iconimage: "+str(iconimage)

################################################
#    Destina para cada modo.                   #
#                                              #
################################################

if mode==None or url==None or len(url)<1:
        print "Sem mode"
        print "Inicio: Menu Principal"
        Menu_Principal()

elif mode==1:
	print "Mode: 1 - Listar Categorias"
	Listar_categorias(url)
	
elif mode==2:
	print "Mode: 2 - Listar Episodios"
	Listar_episodios(url)

elif mode==3:
	print "Mode: 3 - Resolve Episodio"
	Resolve_episodio(url)

elif mode==4:
	print 'Mode: 4 - Pesquisa'
	Pesquisa()
	
xbmcplugin.endOfDirectory(int(sys.argv[1]))